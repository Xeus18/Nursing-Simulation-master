# Nursing-Simulation
This is the github for CSC-4990 project.

# Installation
	1. Follow these steps (https://laravel.com/docs/6.x) to install Laravel onto your system.
	2. Run the command 'composer install' inside the project directory.
	3. Run the command 'npm install' inside the project directory.
	4. Coinfigure env.example, and rename it '.env'
	5. Database
		- Use MySQL to execute the MySQL/CreateNursingDB.sql.
		- This will create a schema called 'nursing' inside your MySQL database. This will host your project's data.
	6. Start server by running the 'run.bat' file, or use the command 'php artisan serve'.
    
    
    
   
